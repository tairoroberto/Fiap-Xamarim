﻿using Xamarin.Forms;

namespace XF.Atividade1
{
    public partial class Atividade1Page : ContentPage
    {
        public Atividade1Page()
        {
            InitializeComponent();
        }
    }
}
