﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using XF.Atividade6.iOS;
using Xamarin.Forms;
using XF.Atividade6.Data;

[assembly: Dependency(typeof(SQLite_iOS))]
namespace XF.Atividade6.iOS
{
    public class SQLite_iOS : ISQLite
    {
        public SQLite_iOS()
        {
        }
        public SQLite.SQLiteConnection GetConexao()
        {
            var arquivodb = "atividade6.db";
            string caminho = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            string bibliotecaPessoal = Path.Combine(caminho, "..", "Library");
            var local = Path.Combine(bibliotecaPessoal, arquivodb);
            var conexao = new SQLite.SQLiteConnection(local);
            return conexao;
        }
    }
}
