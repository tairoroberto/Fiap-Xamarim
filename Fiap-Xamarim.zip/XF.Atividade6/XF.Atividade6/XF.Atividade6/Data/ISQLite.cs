﻿using SQLite;

namespace XF.Atividade6.Data
{
    public interface ISQLite
    {
        SQLiteConnection GetConexao();
    }
}
