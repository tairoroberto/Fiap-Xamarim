﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using XF.Atividade1.Model;

namespace XF.Atividade1
{
    public partial class MainPage : ContentPage
    {
        Email emailmodel;

        public MainPage()
        {
            InitializeComponent();

            if (emailmodel == null)
                emailmodel = new Email();
        }

        private void btnSend_Clicked(object sender, EventArgs e)
        {
            if ((emailmodel.Ativo) && (!string.IsNullOrEmpty(emailmodel.ContaEmail)))
                DisplayAlert("Mensagem",
                    $"E-mail enviado para {emailmodel.ContaEmail}", "Ok");
            else
                DisplayAlert("Mensagem", "Envio não autorizado", "Ok");

        }

        private void btnConfig_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new ConfigPage() { BindingContext = emailmodel });
        }
    }
}
