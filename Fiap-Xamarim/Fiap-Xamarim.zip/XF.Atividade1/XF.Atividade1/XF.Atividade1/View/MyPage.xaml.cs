﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XF.Atividade1
{
    public partial class MyPage : ContentPage
    {
        public MyPage()
        {
            InitializeComponent();
        }
    }
}
