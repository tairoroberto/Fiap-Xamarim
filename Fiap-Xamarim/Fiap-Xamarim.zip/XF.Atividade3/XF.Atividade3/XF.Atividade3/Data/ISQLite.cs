﻿using SQLite;

namespace XF.Atividade3.Data
{
    public interface IDependencyServiceSQLite
    {
        SQLiteConnection GetConexao();
    }
}
