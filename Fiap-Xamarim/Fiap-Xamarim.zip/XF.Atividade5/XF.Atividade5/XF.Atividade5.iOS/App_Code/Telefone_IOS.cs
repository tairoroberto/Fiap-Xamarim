﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;
using XF.Atividade5.iOS.App_Code;
using XF.Atividade5.App_Code;
using Xamarin.Forms;

[assembly: Dependency(typeof(Telefone_IOS))]
namespace XF.Atividade5.iOS.App_Code
{
    public class Telefone_IOS : ITelefone
    {
        public bool Ligar(string numero)
        {
            return UIApplication.SharedApplication.OpenUrl(
                new NSUrl("tel:" + numero));
        }
    }
}