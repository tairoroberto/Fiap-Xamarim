﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XF.Atividade5.App_Code
{
    public interface ITelefone
    {
        bool Ligar(string numero);
    }
}
