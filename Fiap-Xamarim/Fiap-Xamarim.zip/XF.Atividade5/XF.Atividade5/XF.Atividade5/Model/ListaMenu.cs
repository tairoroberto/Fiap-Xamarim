﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XF.Atividade5.Model
{
    public class ListaMenu
    {
        public string Descricao { get; set; }
        public string Icone { get; set; }
        public Type TargetType { get; set; }
    }
}
