﻿using System;

namespace XF.Atividade6.Data
{
	public static class Constants
	{
		// Replace strings with your Azure Mobile App endpoint.
		public static string ApplicationURL = @"https://xf-atividade6.azurewebsites.net";
	}
}

