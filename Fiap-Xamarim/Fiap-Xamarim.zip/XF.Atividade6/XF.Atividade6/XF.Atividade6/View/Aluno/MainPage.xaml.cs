﻿using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XF.Atividade6.ViewModel;

namespace XF.Atividade6.View.Aluno
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            App.AlunoVM.Carregar();
        } 
    }
}
