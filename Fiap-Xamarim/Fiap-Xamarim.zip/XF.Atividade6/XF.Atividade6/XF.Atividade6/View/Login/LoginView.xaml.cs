﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XF.Atividade6.View.Login
{
    public partial class LoginView : ContentPage
    {

        // Track whether the user has authenticated.
        bool authenticated = false;

        public LoginView()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            txtUsuario.Text = pwdSenha.Text = string.Empty;
            base.OnAppearing();

            // Refresh items only when authenticated.
            if (authenticated == true)
            {
                App.Current.MainPage.Navigation.PushAsync(new View.Aluno.MainPage() { BindingContext = App.AlunoVM });
            }

        }

        async void btnLoginFacebook_Clicked(object sender, EventArgs e)
        {
            /* if (App.Authenticator != null)
             {
                 authenticated = await App.Authenticator.Authenticate();
             }*/
            await App.Current.MainPage.Navigation.PushAsync(new View.LoginViewFacebook());
        }
    }
}
