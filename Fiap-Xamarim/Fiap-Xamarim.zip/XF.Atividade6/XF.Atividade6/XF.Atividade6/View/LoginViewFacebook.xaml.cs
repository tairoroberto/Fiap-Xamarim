﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XF.Atividade6.View
{
    public partial class LoginViewFacebook : ContentPage
    {
        public LoginViewFacebook()
        {
            InitializeComponent();
        }
    }
}
